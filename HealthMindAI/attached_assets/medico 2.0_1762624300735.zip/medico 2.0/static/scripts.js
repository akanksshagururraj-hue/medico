// MediCo Frontend Script (no backend, demo-only)
(function(){
  const $ = (sel, root=document) => root.querySelector(sel);
  const $ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  // Simple store using localStorage for demo data
  const store = {
    get patients(){
      try { return JSON.parse(localStorage.getItem('medico_patients')||'[]'); } catch(e){ return [] }
    },
    set patients(v){ localStorage.setItem('medico_patients', JSON.stringify(v)); },
    savePatient(p){ const arr = store.patients; arr.push(p); store.patients = arr; },
    get notes(){ try {return JSON.parse(localStorage.getItem('medico_notes')||'{}')} catch(e){return {}} },
    set notes(v){ localStorage.setItem('medico_notes', JSON.stringify(v)); },
    setPatientNotes(id, text){ const n = store.notes; n[id] = text; store.notes = n; },
    get appointments(){ try {return JSON.parse(localStorage.getItem('medico_appts')||'[]')} catch(e){return []} },
    set appointments(v){ localStorage.setItem('medico_appts', JSON.stringify(v)); },
    get currentUser(){ try {return JSON.parse(localStorage.getItem('medico_user')||'null')} catch(e){return null} },
    set currentUser(v){ if (v) localStorage.setItem('medico_user', JSON.stringify(v)); else localStorage.removeItem('medico_user'); }
  };

  // LOGIN PAGE
  (function initLogin(){
    if (!/login\.html/.test(location.pathname)) return;
    const roleSel = $('#role');
    const uidRow = $('#uidRow');
    const form = $('#loginForm');

    const toggleUID = () => {
      if (roleSel.value === 'Doctor') uidRow.classList.remove('hidden');
      else uidRow.classList.add('hidden');
    };
    roleSel.addEventListener('change', toggleUID);
    toggleUID();

    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      if (!data.email || !data.password) { alert('Email and password are required.'); return; }
      if (data.role === 'Doctor') {
        if (!data.uid || data.uid.trim().length < 4) {
          alert('Please enter a valid Doctor UID (4+ characters)');
          return;
        }
        store.currentUser = { role: 'Doctor', email: data.email, uid: data.uid };
        location.href = 'doctor_dashboard.html';
      } else {
        store.currentUser = { role: 'Patient', email: data.email };
        location.href = 'patient_portal.html';
      }
    });
  })();

  // PAGE GUARDS: restrict access based on role
  (function guards(){
    const p = location.pathname;
    const user = store.currentUser;
    if (/patient_portal\.html/.test(p)){
      if (!user || user.role !== 'Patient') location.href = 'login.html';
    }
    if (/doctor_dashboard\.html/.test(p)){
      if (!user || user.role !== 'Doctor') location.href = 'login.html';
    }
  })();

  // PATIENT PORTAL
  (function initPatientPortal(){
    if (!/patient_portal\.html/.test(location.pathname)) return;
    const form = $('#patientForm');
    const summary = $('#patientSummary');
    const personalInfo = $('#personalInfo');
    const reportList = $('#reportList');
    const painMap = $('#painMap');
    const painMarkers = $('#painMarkers');
    const painList = $('#painList');

    // region-based pain mapping
    const regions = [
      {key:'head', label:'Head', box:[42,5,16,12]},
      {key:'chest', label:'Chest', box:[38,22,24,18]},
      {key:'left_arm', label:'Left Arm', box:[22,22,14,26]},
      {key:'right_arm', label:'Right Arm', box:[64,22,14,26]},
      {key:'abdomen', label:'Abdomen', box:[38,40,24,16]},
      {key:'left_leg', label:'Left Leg', box:[42,58,10,30]},
      {key:'right_leg', label:'Right Leg', box:[52,58,10,30]},
      {key:'joints', label:'Joints', box:[38,56,24,10]},
    ];
    let selectedRegions = new Set();

    function renderRegionOverlays(){
      // build overlays
      painMarkers.innerHTML = '';
      regions.forEach(r=>{
        const el = document.createElement('div');
        el.className = 'pain-region';
        el.style.position='absolute';
        el.style.left = r.box[0] + '%';
        el.style.top = r.box[1] + '%';
        el.style.width = r.box[2] + '%';
        el.style.height = r.box[3] + '%';
        el.style.borderRadius = '12px';
        el.style.cursor = 'pointer';
        el.style.transition = 'all .15s';
        el.dataset.key = r.key;
        el.title = r.label;
        updateRegionStyle(el);
        el.addEventListener('click', (ev)=>{
          ev.stopPropagation();
          if (selectedRegions.has(r.key)) selectedRegions.delete(r.key); else selectedRegions.add(r.key);
          updateRegionStyle(el);
          renderPainList();
        });
        painMarkers.appendChild(el);
      });
    }
    function updateRegionStyle(el){
      const active = selectedRegions.has(el.dataset.key);
      el.style.background = active ? 'rgba(230,57,70,.25)' : 'transparent';
      el.style.outline = active ? '2px solid rgba(230,57,70,.7)' : '1px dashed rgba(16,39,73,.15)';
    }
    function renderPainList(){
      const items = regions.filter(r=>selectedRegions.has(r.key)).map((r,i)=>`<li>${i+1}. ${r.label}</li>`);
      painList.innerHTML = items.length ? items.join('') : '<li>No regions selected</li>';
    }

    renderRegionOverlays();
    renderPainList();

    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      const files = $('#p_reports').files;
      const reportNames = Array.from(files||[]).map(f=>f.name);

      // Render summary UI
      personalInfo.innerHTML = `
        <li><strong>Name:</strong> ${data.p_name}</li>
        <li><strong>Age:</strong> ${data.p_age}</li>
        <li><strong>Gender:</strong> ${data.p_gender}</li>
        <li><strong>DOB:</strong> ${data.p_dob}</li>
        <li><strong>Blood Group:</strong> ${data.p_blood}</li>
        <li><strong>Issue:</strong> ${data.p_issue}</li>
      `;
      reportList.innerHTML = reportNames.length ? reportNames.map(n=>`<li>${n}</li>`).join('') : '<li>No files</li>';

      // Fake AI summary placeholder based on keywords
      const ai = generateAISummary(data.p_issue || '');
      $('#aiSummary').textContent = ai;

      summary.hidden = false;

      // Save to localStorage for doctor dashboard
      const patient = {
        id: 'p_'+Date.now(),
        name: data.p_name,
        age: Number(data.p_age)||'',
        gender: data.p_gender,
        dob: data.p_dob,
        blood: data.p_blood,
        issue: data.p_issue,
        reports: reportNames,
        pain: Array.from(selectedRegions),
        priority: estimatePriority(data.p_issue),
        email: (store.currentUser&&store.currentUser.email)||''
      };
      store.savePatient(patient);
      alert('Submitted! Data stored locally for demo.');
    });

    $('#resetPatientForm')?.addEventListener('click', ()=>{
      selectedRegions = new Set();
      renderRegionOverlays();
      renderPainList();
      summary.hidden = true;
    });

    function generateAISummary(text){
      const t = text.toLowerCase();
      let cues = [];
      if (/(chest|breath|cardiac)/.test(t)) cues.push('Potential cardio-respiratory concern');
      if (/(fever|infection|flu|cough)/.test(t)) cues.push('Possible infectious symptoms');
      if (/(pain|ache|injury|swelling)/.test(t)) cues.push('Pain management may be needed');
      if (/(diabetes|bp|hypertension|sugar)/.test(t)) cues.push('Chronic condition indicators');
      const base = cues.length ? cues.join('; ') : 'No specific risk cues detected. Monitor and review.';
      return base + ' (AI placeholder, non-diagnostic)';
    }

    function estimatePriority(text){
      const t = text.toLowerCase();
      if (/(chest pain|shortness of breath|severe)/.test(t)) return 'High';
      if (/(moderate|persistent|worsening)/.test(t)) return 'Medium';
      return 'Low';
    }
  })();

  // DOCTOR DASHBOARD
  (function initDoctor(){
    if (!/doctor_dashboard\.html/.test(location.pathname)) return;

    const tableBody = $('#patientsTable tbody');
    const detail = $('#patientDetail');
    const docPersonal = $('#docPersonal');
    const docReports = $('#docReports');
    const docPain = $('#docPain');
    const docAISummary = $('#docAISummary');
    const docNotes = $('#docNotes');
    const saveNotesBtn = $('#saveNotes');
    const apptPatient = $('#apptPatient');
    const apptForm = $('#appointmentForm');
    const apptTableBody = $('#appointmentsTable tbody');

    const patients = store.patients;

    // Populate table
    function renderTable(){
      tableBody.innerHTML = '';
      patients.forEach(p=>{
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><a href="#" data-id="${p.id}" class="link">${p.name}</a></td>
          <td>${p.age}</td>
          <td>${(p.issue||'').slice(0,60)}${(p.issue||'').length>60?'…':''}</td>
          <td><span class="badge badge-${p.priority.toLowerCase()}">${p.priority}</span></td>
          <td><button class="btn btn-secondary" data-view="${p.id}">View</button></td>
        `;
        tableBody.appendChild(tr);
      });
    }

    // Populate select for appointments
    function renderPatientSelect(){
      apptPatient.innerHTML = patients.map(p=>`<option value="${p.id}">${p.name}</option>`).join('');
    }

    // Click handlers
    tableBody.addEventListener('click', (e)=>{
      const id = e.target.getAttribute('data-view') || e.target.getAttribute('data-id');
      if (!id) return;
      const p = patients.find(x=>x.id===id); if (!p) return;
      viewPatient(p);
    });

    function viewPatient(p){
      docPersonal.innerHTML = `
        <li><strong>Name:</strong> ${p.name}</li>
        <li><strong>Age:</strong> ${p.age}</li>
        <li><strong>Gender:</strong> ${p.gender}</li>
        <li><strong>DOB:</strong> ${p.dob}</li>
        <li><strong>Blood:</strong> ${p.blood}</li>
        <li><strong>Priority:</strong> ${p.priority}</li>
        <li><strong>Issue:</strong> ${p.issue}</li>
      `;
      docReports.innerHTML = (p.reports||[]).length ? p.reports.map(r=>`<li>${r}</li>`).join('') : '<li>No reports</li>';
      // show selected regions in readable labels
      const regionNames = {
        head:'Head', chest:'Chest', left_arm:'Left Arm', right_arm:'Right Arm', abdomen:'Abdomen', left_leg:'Left Leg', right_leg:'Right Leg', joints:'Joints'
      };
      docPain.innerHTML = (p.pain||[]).length ? p.pain.map((k,i)=>`<li>${i+1}. ${regionNames[k]||k}</li>`).join('') : '<li>No pain regions</li>';
      docAISummary.textContent = inferAISummary(p);
      docNotes.value = (store.notes||{})[p.id] || '';
      saveNotesBtn.onclick = ()=>{ store.setPatientNotes(p.id, docNotes.value); alert('Notes saved locally.'); };
      detail.hidden = false;
    }

    function inferAISummary(p){
      // simple reuse of estimating logic
      const base = p.issue || '';
      let cues = [];
      if (/(chest|breath|cardiac)/i.test(base)) cues.push('Potential cardio-respiratory concern');
      if (/(fever|infection|flu|cough)/i.test(base)) cues.push('Possible infectious symptoms');
      if (/(pain|ache|injury|swelling)/i.test(base)) cues.push('Pain management may be needed');
      if (/(diabetes|bp|hypertension|sugar)/i.test(base)) cues.push('Chronic condition indicators');
      return (cues.length?cues.join('; '):'No specific risk cues detected. Monitor and review.') + ' (AI placeholder)';
    }

    // Simple calendar for current month
    function renderCalendar(){
      const cal = $('#calendar');
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth()+1, 0);
      const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      cal.innerHTML = '';
      dayNames.forEach(d=>{
        const el = document.createElement('div'); el.textContent = d; el.className='day name'; cal.appendChild(el);
      });
      for (let i=0;i<start.getDay();i++){ const ph=document.createElement('div'); ph.className='day'; cal.appendChild(ph); }
      for (let d=1; d<=end.getDate(); d++){
        const el = document.createElement('div');
        el.className='day';
        el.innerHTML = `<div class="n">${d}</div>`;
        cal.appendChild(el);
      }
    }

    // Appointments
    function renderAppointments(){
      const appts = store.appointments;
      apptTableBody.innerHTML = appts.map(a=>{
        const p = patients.find(x=>x.id===a.patientId);
        return `<tr><td>${p?p.name:'Unknown'}</td><td>${a.date}</td><td>${a.time}</td><td>${a.notes||''}</td></tr>`;
      }).join('');
    }

    apptForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const patientId = $('#apptPatient').value;
      const date = $('#apptDate').value;
      const time = $('#apptTime').value;
      const notes = $('#apptNotes').value;
      if (!patientId || !date || !time) { alert('Please select patient, date and time.'); return; }
      const arr = store.appointments; arr.push({patientId, date, time, notes}); store.appointments = arr;
      renderAppointments();
      alert('Appointment scheduled (demo).');
      apptForm.reset();
    });

    renderTable();
    renderPatientSelect();
    renderCalendar();
    renderAppointments();
  })();

  // PATIENT VIEW: show upcoming appointments only
  (function initPatientAppointments(){
    if (!/patient_portal\.html/.test(location.pathname)) return;
    // create a lightweight upcoming section if not present
    let upcoming = document.getElementById('upcomingAppts');
    if (!upcoming){
      upcoming = document.createElement('section');
      upcoming.className = 'card';
      upcoming.id = 'upcomingAppts';
      upcoming.innerHTML = '<h2>Upcoming Appointments</h2><ul class="data-list" id="upcomingList"></ul>';
      document.querySelector('main .container, main.container')?.appendChild(upcoming);
    }
    const list = document.getElementById('upcomingList');
    const user = store.currentUser;
    const appts = store.appointments;
    const patients = store.patients;
    // find current patient's records by email
    const myIds = patients.filter(p=>p.email && user && p.email===user.email).map(p=>p.id);
    const mine = appts.filter(a=> myIds.includes(a.patientId));
    list.innerHTML = mine.length ? mine.map(a=>`<li>${a.date} ${a.time} — ${a.notes||''}</li>`).join('') : '<li>No upcoming appointments</li>';
  })();

  // BADGES + pain region style
  (function addStyles(){
    const s = document.createElement('style');
    s.textContent = `
      .badge{display:inline-block; padding:2px 8px; border-radius:999px; font-size:12px; font-weight:600}
      .badge-high{background:#ffe6e9; color:#b31725}
      .badge-medium{background:#fff2d6; color:#8a6100}
      .badge-low{background:#e6f6ff; color:#0a5a96}
      .link{color:#1f6feb; text-decoration:none}
      .link:hover{text-decoration:underline}
      .pain-region{mix-blend-mode:multiply}
    `;
    document.head.appendChild(s);
  })();
})();
